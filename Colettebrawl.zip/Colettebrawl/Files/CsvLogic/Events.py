from Files.CsvReader import CsvReader
class Events:
	def parse(self, t):
		r = CsvReader()
		l = []
		r=r.readCsv("GameAssets/csv_logic/parser.csv")
		for i in r:
			if i[0].startswith(t):
				if i[1]!="true":
					l.append(r.index(i))
		return l
		