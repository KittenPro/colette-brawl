import time, json, random
from Files.CsvLogic.Events import Events
class EventSlots:
    def loadEvents(self):
    	with open("Logic/events.json", "r") as f:
    		data=json.load(f)
    		return data
    def updateEventData(self, i, new):
    	with open("Logic/events.json", "r") as f:
    		data=json.load(f)
    	try:
    		data[str(i)]["ID"]=new
    	except:
    		data[str(i)]={}
    		data[str(i)]["ID"]=new
    	with open("Logic/events.json", "w") as f:
    		json.dump(data,f)
    def SetEventSlotsData(self):
    	gems = random.choice([7,8,9,10,11,12, 124])
    	sd = random.choice([13,14,15, 43,16])
    	bb = random.choice([24, 25, 50, 51])
    	bb = random.choice([24, 25, 26, 50, 51, 52])
    	heist = random.choice([17, 18, 19])
    	star = random.choice([54])
    	robowars = random.choice([110, 111])
    	EventSlots.updateEventData(self, 0, bb)
    	EventSlots.updateEventData(self, 1, sd)
    	EventSlots.updateEventData(self, 2, heist)
    	EventSlots.updateEventData(self, 3, gems)
    	EventSlots.updateEventData(self, 4, star)
    	EventSlots.updateEventData(self, 5, robowars)
    def offset(self):
        event = EventSlots.loadEvents(self)
        count = len(event)
        self.writeVint(count+1)  # Event slot count
        for i in range(count+1):
        	self.writeVint(i)
        	
        self.writeVint(count)
        c=1
        for i in event.values():
            print(i)
            self.writeVint(c)
            self.writeVint(c)
            self.writeVint(0)  # IsActive | 0 = Active, 1 = Disabled
            self.writeVint(25565)  # Timer

            self.writeVint(1)
            self.writeScId(15, i["ID"])

            self.writeVint(3)

            self.writeString() # "Double Experience Event" Text
            self.writeVint(0)
            self.writeVint(0)  # Powerplay game played
            self.writeVint(3)  # Powerplay game left maximum
            self.writeBoolean(False) # Modifier Boolean

            self.writeVint(0)
            self.writeVint(0)
            c+=1
    	
    Timer = 86399

    maps = [
        # Status = [3 = Nothing, 2 = Star Token, 1 = New Event]
        {
            'ID': 7,
            'Status': 2,
            'Ended': False,
            'Modifier': 11,
            'Tokens': 10
        },

        {
            'ID': 32,
            'Status': 2,
            'Ended': False,
            'Modifier': 11,
            'Tokens': 10
        },

        {
            'ID': 17,
            'Status': 2,
            'Ended': False,
            'Modifier': 11,
            'Tokens': 10
        },

        {
            'ID': 0,
            'Status': 2,
            'Ended': False,
            'Modifier': 0,
            'Tokens': 10
        },

        {
            'ID': 38,
            'Status': 2,
            'Ended': False,
            'Modifier': 11,
            'Tokens': 10
        },

        {
            'ID': 24,
            'Status': 2,
            'Ended': False,
            'Modifier': 11,
            'Tokens': 10
        },

        {
            'ID': 21,
            'Status': 2,
            'Ended': False,
            'Modifier': 11,
            'Tokens': 2
        },

        {
            'ID': 97,
            'Status': 2,
            'Ended': False,
            'Modifier': 11,
            'Tokens': 10
        }

    ]