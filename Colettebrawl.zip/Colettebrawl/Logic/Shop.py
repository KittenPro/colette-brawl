import json, random
from Files.CsvReader import CsvReader
class Shop:
    """
    << Shop Offers IDs List >>

    0 = Free Brawl Box
    1 = Gold
    2 = Random Brawler
    3 = Brawler
    4 = Skin
    5 = StarPower/ Gadget
    6 = Brawl Box
    7 = Tickets
    8 = Power Points (for a specific brawler)
    9 = Token Doubler
    10 = Mega Box
    11 = Keys (???)
    12 = Power Points
    13 = EventSlot (???)
    14 = Big Box
    15 = AdBox (not working anymore)
    16 = Gems

    """
    def loadOffers(self):
    	self.offers=[]
    	with open("offers.json", "r") as f:
    		data = json.load(f)
    		for i in data.values():
    			self.offers.append(i)
    def UpdateOfferData(self, i):
    	with open("offers.json", "r") as f:
    		data = json.load(f)
    	data[str(i)]["WhoBuyed"].append(int(self.player.low_id))
    	with open("offers.json", "w") as f:
    		json.dump(data, f, ensure_ascii=False)
    def RemoveOffer(self, i):
    	with open("offers.json", "r") as f:
    		data = json.load(f)
    	data.pop(str(i))
    	with open("offers.json", "w") as f:
    		json.dump(data, f, ensure_ascii=False)
    gold = [
        {
            'Cost': 20,
            'Amount': 150
        },

        {
            'Cost': 50,
            'Amount': 400
        },

        {
            'Cost': 140,
            'Amount': 1200
        },

        {
            'Cost': 280,
            'Amount': 2600
        },

    ]

    boxes = [
        {
            'Name': 'Big Box',
            'Cost': 30,
            'Multiplier': 3
        },

        {
            'Name': 'Mega Box',
            'Cost': 80,
            'Multiplier': 10
        }

    ]


    token_doubler = {

        'Cost': 50,
        'Amount': 1000
    }


    def EncodeShopOffers(self):
        #SkinParser.SetSkinOffers(self)
        Shop.loadOffers(self)
        wow = self.offers
        count = len(wow)
        self.writeVint(count)
        for i in range(count):
            item = wow[i]
            self.writeVint(1)
            for l in range(1):
            	self.writeVint(item['ID']) # ItemID
            	self.writeVint(item['Doubler']) # Ammount
            	self.writeVint(0)
            	self.writeVint(item['skin4ik'])           
            
            self.writeVint(item['Type'])  # [0 = Offer, 2 = Skins 3 = Star Shop]
            self.writeVint(item['Cost'])  # Cost
            self.writeVint(20) # Timer
            self.writeVint(1)
            self.writeVint(100)
            if self.player.low_id in item["WhoBuyed"]:
            		self.writeBoolean(True)
            else:
            		self.writeBoolean(False)
            self.writeBoolean(False)
            self.writeVint(item['Display'])  # [0 = Normal, 1 = Daily Deals]
            self.writeBoolean(False)
            self.writeVint(0)
            
            self.writeInt(0)
            self.write_string_reference(item['Title'])
            self.writeBoolean(False)
            self.writeString()
            self.writeVint(0)
            self.writeBoolean(False)
            self.writeVint(2)
            self.writeVint(item["%"]) # % Extra Text
class SkinParser:
	def SetSkinOffers(self):
	   	r=CsvReader().readCsv("GameAssets/csv_logic/skins.csv")
	   	skindata = []
	   	for i in r:
	   				skindata.append(i)
	   	for i in range(2):
	   				with open("offers.json", "r+") as f:
	   					data = json.load(f)
	   				lenght = str(len(data))
	   				data[lenght]={}
	   				data[lenght]["ID"]=4
	   				data[lenght]["Doubler"]=1
	   				data[lenght]["brawler"]=0
	   				ch = random.choice(skindata)
#	   				ch = skindata[skindata.index(ch)+1]
	   				while not ch[12]!='' and not ch[10].startswith('TID'):
	   					ch = random.choice(skindata)
#	   					ch = skindata[skindata.index(ch)+1]
	   				data[lenght]["skin4ik"]=int(skindata.index(ch))
	   				skindata.pop(skindata.index(ch))
	   				if ch[7]!='' and ch[8]=='':
	   					data[lenght]["Type"]=3
	   				else:
	   					data[lenght]["Type"]=0
	   				if ch[8]!='':
	   					data[lenght]["Cost"]=int(ch[8])
	   				elif ch[7]!='':
	   					data[lenght]["Cost"]=int(ch[7])
	   				elif ch[9]!='':
	   					data[lenght]["Cost"]=int(ch[9])
	   				else:
	   					data[lenght]["Cost"]=1
	   				data[lenght]["WhoBuyed"]=[]
	   				data[lenght]["Display"]=0
	   				data[lenght]["Title"]="SkinOffer"
	   				data[lenght]["%"]=0
	   				print(f"{ch}")
	   				with open("offers.json", "w") as f:
	   					json.dump(data,f)