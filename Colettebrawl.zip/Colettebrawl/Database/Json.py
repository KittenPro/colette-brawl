import json as j
class Json:
	def AddOffer(self, token, offer):
		with open("Database/shop.db", "r") as f:
			data = j.load(f)
		if not token in data:
			data[token] = {}
			data[token][offer] = False
		else:
			data[token][offer] = False
		with open("Database/shop.db", "w") as f:
			j.dump(data,f)
	def LoadOffer(self, token):
		with open("Database/shop.db", "r") as f:
			data = j.load(f)
		if data[f"{token}"]:
			return data[token]
		else:
			return Json.AddOffer(self, "xxxx", "pornhub")