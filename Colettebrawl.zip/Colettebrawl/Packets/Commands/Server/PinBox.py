from Database.DatabaseManager import DataBase
from Packets.Messages.Server.OutOfSyncMessage import OutOfSyncMessage
import random

from Utils.Writer import Writer
class PinBox(Writer):
	def __init__(self, client, player):
	       super().__init__(client)
	       self.id = 24111
	       self.player = player
	       self.pin = random.randint(1, 10)
	def encode(self):
	 	self.writeVint(203) # CommandID
	 	self.writeVint(0)   # Unknown
	 	self.writeVint(1)   # Multipler
	 	self.writeVint(10) # BoxID
	 	self.writeVint(1) 
	 	self.writeVint(1)
	 	self.writeVint(0)
	 	self.writeVint(11)
	 	self.writeVint(0) # CsvID 29
	 	self.writeScId(52, 317) # CsvID 52
	 	self.writeVint(0) # CsvID 23
	 	self.writeVint(0)
	 	
	 	self.writeVint(1)
	 	self.writeVint(0)
	 	self.writeVint(11)
	 	for i in range(13):
	 		self.writeVint(0)