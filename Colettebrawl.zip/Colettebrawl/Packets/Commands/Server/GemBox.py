from Database.DatabaseManager import DataBase
from Packets.Messages.Server.OutOfSyncMessage import OutOfSyncMessage

from Utils.Writer import Writer
class GemBox(Writer):
	def __init__(self, client, player, count):
	       super().__init__(client)
	       self.id = 24111
	       self.player = player
	       self.count = count
	def encode(self):
	 	self.writeVint(203) # CommandID
	 	self.writeVint(0)   # Unknown
	 	self.writeVint(1)   # Multipler
	 	self.writeVint(10) # BoxID
	 	self.writeVint(1)
	 	self.player.gems += self.count
	 	DataBase.replaceValue(self, 'gems', self.player.gems)
	 	self.writeVint(self.count)#count
	 	self.writeVint(0)
	 	self.writeVint(8)#ID
	 	self.writeVint(0)
	 	self.writeVint(0)
	 	self.writeVint(0)
	 	self.writeVint(0)
	 	for x in range(13):
	 		self.writeVint(0)