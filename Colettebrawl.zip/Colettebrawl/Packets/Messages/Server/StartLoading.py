from Utils.Writer import Writer
import random

class StartLoadingMessage(Writer):

    def __init__(self, client, player):
        super().__init__(client)
        self.id = 20559
        self.player = player

    def encode(self):
        self.writeInt(1) #6
        self.writeInt(0)
        self.writeInt(0)
        
        self.writeInt(1) #players count
        
        self.writeInt(self.player.high_id) #High ID
        self.writeInt(self.player.low_id) #Low ID
        self.writeVint(0)
        self.writeVint(0)
        self.writeVint(0)
        self.writeVint(0)
        
        self.writeInt(0) #unk
        
        self.writeScId(16, self.player.brawler_id)
        self.writeVint(0)
        self.writeByte(0)
        self.writeString(self.player.name)
        self.writeVint(100)
        self.writeVint(28000000)
        self.writeVint(43000000)
        self.writeVint(0)
        self.writeByte(0)
        #PLAYERS SLOT END#
        
        self.writeInt(0) #count...
        
        self.writeInt(0) #Count
        
        self.writeInt(0) # Unknown
        
        self.writeVint(0)
        self.writeVint(1) #DrawMap
        self.writeVint(1)
        
        self.writeByte(1) #2, 39 - Spectating
        self.writeVint(0) # Unknown
        self.writeVint(0)
        
        self.writeScId(15, 7)
        self.writeVint(0)
        self.writeVint(0)
        self.writeVint(0)
        self.writeVint(0)
        
        print("StartLoadingMessage sent.")