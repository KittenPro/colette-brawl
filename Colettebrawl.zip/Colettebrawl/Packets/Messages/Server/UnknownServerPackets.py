from Utils.Writer import Writer


class UnknownServerPackets(Writer):

    def __init__(self, client, player, VInt):
        super().__init__(client)
        self.id = VInt
        self.player = player

    def encode(self):
    	pass

